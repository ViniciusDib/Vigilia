# Handoff: Asylum Monster Room (pixel-art horror scene)

## Overview
A first-person horror scene rendered as 320×180 procedural pixel art. The player has stumbled into a blood-soaked room in an abandoned mental asylum. A flayed, hooded monster with a huge vertical, tooth-lined mouth stands in the middle. The room is lit only by the player's flashlight, which follows the cursor or touch. The beam has a bright core, a soft outer glow and darkness beyond.

## About the Design Files
`Asylum Room.dc.html` is an HTML **design reference/prototype**, not production code. Recreate it in the target environment (a game engine such as Godot, Unity or Phaser, or a web canvas/WebGL app). If there is no codebase yet, pick the best fit. Treat all of the logic, parameters and colors below as the spec. Open the HTML file in a browser to see it running. `support.js` is the small runtime the prototype needs; it is not part of the design.

## Fidelity
**High-fidelity.** The palette, geometry, lighting model and timings are final. The art is generated in code (no sprite files). A pixel artist could re-paint it as sprites, as long as the layout, palette and lighting behaviour stay the same.

## Rendering pipeline (per frame)
1. **Albedo pass (once at load):** fill these per-pixel buffers at 320×180: base color R/G/B (0–1), depth `Z`, specular/wetness `S` (0–1), emissive `EM` (eyeshine mask) and surface id `SF`.
2. **Eye update:** restore each eye's saved pixel box, then draw the pupil, iris and blink.
3. **Lighting:** for each pixel, `L = 0.06 (ambient) + beam`.
   - `d = distance(pixel, lightCenter) / R0`, where `R0 = 30px × beamSize`.
   - Outer glow: `0.24 × (1 − smoothstep(0.95, 2.1, d))`
   - Core: `0.85 × (1 − smoothstep(0.82, 1.03, d)) × (1 − 0.22d²)`
   - Hot ring: `+0.12 × exp(−(d−0.86)² × 300)`
   - Reflector dark spot: `−0.06 × exp(−d² × 40)`
   - Distance falloff: `beam × min(1.25, 1.35 / Z) × flickerIntensity`
4. **Dither (optional):** `Lq = floor(L×9 + bayer4x4/16) / 9`.
5. **Color:** `rgb = albedo × Lq × (1.55, 1.4, 1.2)` (warm flashlight tint).
   - Wet highlights: `+ S × max(0, beam − 0.55) × 1.6 × (1, .9, .75)`.
   - Eyeshine: `+ EM × k × (1 − min(1, beam×1.3)) × (1, .62, .2)`. `k = 0.42`, or `0.7` during a flicker blackout. It also pulses slowly: `×(0.8 + 0.2 sin(1.3t))`.
   - Film grain: `±0.0175` random per pixel.
6. **Palette snap:** look up the nearest palette color in a 32³ table. Distance weights: R×3, G×4, B×2.
7. **Dust motes:** 70 drifting particles. They are drawn only inside the beam core, brightened by `0.3 × (1 − d)`.
8. Upscale with nearest-neighbour filtering (`image-rendering: pixelated`). Keep the 16:9 frame letterboxed on `#050304`.

## Room geometry (one-point perspective)
- Vanishing point (160, 80). The back wall sits at depth `t0 = 0.38` (screen box ≈ x 99–221, y 50–118).
- For each pixel: `tFloor = dy/100`, `tCeil = −dy/80`, `tWall = |dx|/160`. The largest value picks the surface. If all are below `t0`, the pixel is on the back wall.
- World-to-screen projection: `P(X, Y, Z) = (160 + X/Z, 80 + Y/Z)`. The floor is at Y = +100, the ceiling at Y = −80 and the side walls at X = ±160.
- **Walls:** dirty plaster above, institutional green-grey tiles below (14×11 units, starting at v > 28) and a dark baseboard (v > 92). Vertical streaks of blood from noise cover about half the area; there is more blood higher up, and everything has a red wash.
- **Floor:** wooden planks 22 units wide running toward the back wall, with grain, seams, grime near the walls and soaked-in blood stains.
- **Ceiling:** 40-unit panels with water stains, blood spray and some missing panels (black).

## Props and decals
- **Cell door** (right wall, Z 1.5–2.05): rusty green-grey steel with a dark barred window. Two emissive pixels in the window (250, 90) and (252, 90) are eyes that glow in the dark. Four claw scratches and a handle.
- **Restraint bed** (left wall, Z 1.2–1.8, X −158 to −100): rusty metal headboard and footboard, stained mattress with a blood blob, two leather straps and one loose strap with a buckle.
- **Hanging lamp:** a broken cage lamp hangs at (210, 23–48).
- **Blood:**
  - Splatters with surrounding droplets and drips.
  - Handprints: three on the left wall, one on the right. Each has a palm, five fingers and a smear sliding down.
  - "HELP" in a 3×5 pixel font at 2× scale, at (189, 58) on the back wall, with drips.
  - Floor pools (squashed to 0.3 height, glossy).
  - A drag trail from the bottom of the screen to the monster's feet.
- **Floor clutter:** scattered paper files and shadows under the bed and the monster.

## Monster (centered at x = 160, depth Z = 1.6, feet at y ≈ 142)
- **Silhouette half-width by row:**
  - y 32–54: round head top, radius 21.
  - y 54–98: widens slowly to about 23.6.
  - y 98–114: smooth flare to 45 (shoulders).
  - Below 114: tapers by 0.22 per row.
  - Edges are ragged noise; the bottom hem is ragged around y 136–144.
- **Flesh:** lumpy noise blending `(0.34, .03, .03)` → `(0.8, .12, .09)`, shaded like a cylinder.
  - The face oval (rx 18.5, ry 46, centered at y 78) is brighter; outside it the hood is darker and folded.
  - Random wet speculars, about 12 dark branching veins, and bone-colored nodules.
- **Eyes:**
  - Left: center (150, 50), radii 4.4×3.5.
  - Right: center (169, 51), radii 4.9×3.9. The two eyes are deliberately uneven.
  - Forehead slit eye: center (160, 39), radii 1.8×3.2, amber sclera.
  - Big eyes:
    - Black sunken socket and swollen red lid ring.
    - Sickly yellow sclera with red veins.
    - 3×3 blood-red iris.
    - The pupil is a single pixel when the beam is on the eye and a plus-shape when it's in the dark.
    - Blood tears run 16–30px down the face.
- **Eye behaviour:**
  - The pupils follow the light center: offset `round(dx/18)` clamped to ±2 and `round(dy/26)` clamped to ±1. The forehead eye's slit only moves ±1 horizontally.
  - Each eye twitches on its own, glancing randomly every 0.8–4.3s for 0.1–0.4s.
  - Each eye blinks on its own, taking 0.22s. Big eyes blink every 2.5–8.5s; the forehead eye every 1.2–7.2s.
- **Nose:** an inverted-heart cavity at y 56–61.
- **Mouth:** a vertical ellipse centered at (160, 93), ry 27, with rx tapering from about 8 at the top to 13, then about 9.
  - Inside: gum blending into a near-black throat (centered at y 84), with a tongue at (160, 113).
  - Lips: a dark inner rim and a swollen, glossy outer lip.
  - Teeth: an outer ring of 2×2 teeth every 3.1px and an inner ring every 4.2px. About 8% of teeth are missing and 12% are rotten.
  - Eight long needle fangs, 5–8px, with bloody tips.
  - Rows of teeth also run down both sides of the body and along the chin.
  - Translucent saliva strands, one of them broken, a drool string, and blood drips from the lower lip.
- **Arms:** thin, outlined arms hang from the shoulders (±39, 108) to the wrists (±45, 131). Each hand has four long fingers with pale claw tips.

## Interactions & Behavior
- **Aiming:** the flashlight follows the mouse or touch, eased at 0.1 per frame. A handheld wobble is added: x `sin(1.7t)·1.2 + sin(.53t)·2.2`, y `cos(1.3t) + sin(.41t)·1.6`.
- **Idle:** with no pointer, the light wanders: `x = 160 + 55 sin(.31t) + 10 sin(.83t)`, `y = 86 + 26 sin(.47t)`.
- **Cursor:** hidden. The hint "MOVE TO AIM THE FLASHLIGHT" (monospace, 11px, 0.3em letter-spacing, `#6b1214`) disappears on the first move.
- **Flicker:** a constant shimmer of `0.97 + 0.03·sin(23t)·sin(7.1t)`. Each frame there is a 0.25% chance of a 0.15–0.5s burst, during which the intensity randomly jumps between 0.35 and 1, with a 30% chance of near-black (0.05).

## Settings (tweakable)
- `beamSize`: 0.6–1.6. Default 1; the user preferred 1.25.
- `flicker`: on/off, default on.
- `eyesFollow`: on/off, default on. When off, the eyes stare straight ahead.
- `dither`: Bayer 4×4 light banding on/off. Default on; the user preferred off.

## Design Tokens — palette (30 colors, the final output snaps to these)
- **Blacks:** `#050304 #0c0607 #150909 #1f0c0c`
- **Reds:** `#2a0a0b #3d0d0e #521012 #6b1214 #851417 #a3191b #c02a23 #d9473a`
- **Flesh:** `#e0705f #f09a86`
- **Browns:** `#2b1a10 #3f2616 #573520 #70472a #8c5c38 #a87748`
- **Bone:** `#c9b27a #e3d29a #f4ead0`
- **Greys:** `#262626 #3a3836 #55524d #7a756b`
- **Grime green:** `#2f3328 #4a5040`
- **Light:** `#fff6e0`

## Assets
- No image assets; everything is generated in code with a seeded random generator (mulberry32, seed 7331) and value noise / fbm.
- `reference/`: the user's mood references (monster face, blood-red room). They are inspiration only, not for direct use.

## Files
- `Asylum Room.dc.html`: the full prototype. All rendering is in the logic class: `build()` creates the scene once and `frame()` runs every frame.
- `support.js`: the prototype's runtime.
- `reference/*.png`: mood references.
